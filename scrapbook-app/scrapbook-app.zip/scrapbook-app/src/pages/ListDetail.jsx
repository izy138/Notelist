import { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import {
  DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors
} from '@dnd-kit/core'
import {
  SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy, arrayMove
} from '@dnd-kit/sortable'
import { ArrowLeft, Archive, Calendar, ChevronDown, ChevronUp, RotateCcw, Trash2, Pencil, Check, X } from 'lucide-react'
import { format } from 'date-fns'
import useListStore from '../store/useListStore'
import ListItem from '../components/lists/ListItem'
import AddItemBar from '../components/lists/AddItemBar'

export default function ListDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { lists, reorderItems, updateList, deleteArchivedItem, clearArchive, unarchiveItem } = useListStore()
  const list = lists.find(l => l.id === id)

  const [showArchive, setShowArchive] = useState(false)
  const [editingTitle, setEditingTitle] = useState(false)
  const [titleDraft, setTitleDraft] = useState(list?.name || '')

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  )

  if (!list) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen gap-4">
        <p className="text-[#9ca3af]">List not found</p>
        <button onClick={() => navigate('/lists')} className="text-sm text-[#2C3E6B] hover:underline">
          ← Back to lists
        </button>
      </div>
    )
  }

  const handleDragEnd = (event) => {
    const { active, over } = event
    if (active.id !== over?.id) {
      const oldIndex = list.items.findIndex(i => i.id === active.id)
      const newIndex = list.items.findIndex(i => i.id === over.id)
      reorderItems(list.id, arrayMove(list.items, oldIndex, newIndex))
    }
  }

  const saveTitle = () => {
    if (titleDraft.trim()) updateList(list.id, { name: titleDraft.trim() })
    setEditingTitle(false)
  }

  const isOverdue = list.dueDate && new Date(list.dueDate) < new Date() && list.items.length > 0

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <div className="sticky top-0 z-30 px-4 pt-4 pb-3"
        style={{ background: 'rgba(250,248,245,0.97)', backdropFilter: 'blur(8px)', borderBottom: '1px solid #e8e4de' }}>
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/lists')}
            className="p-2 -ml-2 rounded-xl hover:bg-[#f0ece6] transition-colors">
            <ArrowLeft size={18} className="text-[#6b7280]" />
          </button>

          <div className="flex items-center gap-2 flex-1 min-w-0">
            <span className="text-2xl">{list.emoji}</span>
            {editingTitle ? (
              <div className="flex items-center gap-2 flex-1">
                <input
                  value={titleDraft}
                  onChange={e => setTitleDraft(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') saveTitle(); if (e.key === 'Escape') setEditingTitle(false) }}
                  onBlur={saveTitle}
                  autoFocus
                  className="flex-1 font-serif text-xl italic bg-transparent outline-none border-b-2"
                  style={{ borderColor: list.color }}
                />
                <button onClick={saveTitle}><Check size={16} style={{ color: list.color }} /></button>
                <button onClick={() => setEditingTitle(false)}><X size={16} className="text-[#9ca3af]" /></button>
              </div>
            ) : (
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <h1 className="font-serif text-xl italic truncate">{list.name}</h1>
                <button onClick={() => { setTitleDraft(list.name); setEditingTitle(true) }}
                  className="flex-shrink-0 p-1 rounded hover:bg-[#f0ece6] transition-colors">
                  <Pencil size={13} className="text-[#9ca3af]" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Stats row */}
        <div className="flex items-center gap-3 mt-2 ml-10">
          <span className="text-xs text-[#9ca3af]">
            {list.items.length} item{list.items.length !== 1 ? 's' : ''}
          </span>
          {list.archivedItems.length > 0 && (
            <span className="text-xs text-[#9ca3af]">
              · {list.archivedItems.length} done
            </span>
          )}
          {list.dueDate && (
            <span className={`flex items-center gap-1 text-xs ${isOverdue ? 'text-red-500' : 'text-[#9ca3af]'}`}>
              <Calendar size={11} />
              {format(new Date(list.dueDate), 'MMM d, yyyy')}
            </span>
          )}
        </div>
      </div>

      {/* Items */}
      <div className="flex-1 px-4 pt-2 pb-4">
        {list.items.length === 0 && list.archivedItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="text-5xl mb-3">{list.emoji}</div>
            <p className="text-sm text-[#9ca3af] italic font-serif">List is empty.</p>
            <p className="text-xs text-[#d1d5db] mt-1">Add your first item below</p>
          </div>
        ) : (
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
            <SortableContext items={list.items.map(i => i.id)} strategy={verticalListSortingStrategy}>
              {list.items.map(item => (
                <ListItem key={item.id} item={item} listId={list.id} listColor={list.color} />
              ))}
            </SortableContext>
          </DndContext>
        )}

        {/* Archive section */}
        {list.archivedItems.length > 0 && (
          <div className="mt-6">
            <button
              onClick={() => setShowArchive(!showArchive)}
              className="flex items-center gap-2 text-xs font-medium text-[#9ca3af] hover:text-[#6b7280] transition-colors mb-3">
              <Archive size={13} />
              Archived ({list.archivedItems.length})
              {showArchive ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
            </button>

            {showArchive && (
              <div className="fade-in">
                {list.archivedItems.map(item => (
                  <div key={item.id}
                    className="ruled-item flex items-center gap-3 py-2.5 px-1 group opacity-50">
                    <span className="strikethrough flex-1 text-sm text-[#6b7280] font-serif italic">
                      {item.text}
                    </span>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => unarchiveItem(list.id, item.id)}
                        className="p-1 rounded hover:bg-[#e8edf7] transition-colors" title="Restore">
                        <RotateCcw size={12} className="text-[#2C3E6B]" />
                      </button>
                      <button onClick={() => deleteArchivedItem(list.id, item.id)}
                        className="p-1 rounded hover:bg-red-50 transition-colors">
                        <Trash2 size={12} className="text-red-400" />
                      </button>
                    </div>
                  </div>
                ))}
                <button
                  onClick={() => clearArchive(list.id)}
                  className="mt-3 text-xs text-red-400 hover:text-red-600 transition-colors">
                  Clear all archived
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Add item bar */}
      <AddItemBar listId={list.id} listColor={list.color} />
    </div>
  )
}
