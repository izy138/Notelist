import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { nanoid } from 'nanoid'

export const PIN_TYPES = {
  link: { label: 'Link', emoji: '🔗' },
  note: { label: 'Note', emoji: '📝' },
  tweet: { label: 'Tweet', emoji: '🐦' },
  bookmark: { label: 'Bookmark', emoji: '🔖' },
}

function detectPinType(url) {
  if (!url) return 'note'
  try {
    const u = new URL(url)
    const host = u.hostname.replace('www.', '')
    if (host === 'twitter.com' || host === 'x.com') return 'tweet'
    return 'link'
  } catch {
    return 'note'
  }
}

function extractTweetId(url) {
  try {
    const match = url.match(/\/status\/(\d+)/)
    return match ? match[1] : null
  } catch {
    return null
  }
}

const useClipboardStore = create(
  persist(
    (set) => ({
      pins: [],
      tags: ['recipes', 'inspo', 'work', 'later', 'read'],

      addPin: ({ content, type, title, tags = [], color }) => {
        const resolvedType = type || detectPinType(content)
        const tweetId = resolvedType === 'tweet' ? extractTweetId(content) : null
        set(state => ({
          pins: [
            {
              id: nanoid(),
              content,
              type: resolvedType,
              title: title || '',
              tweetId,
              tags,
              color: color || null,
              pinnedAt: Date.now(),
            },
            ...state.pins,
          ]
        }))
      },

      updatePin: (pinId, updates) =>
        set(state => ({
          pins: state.pins.map(p => p.id === pinId ? { ...p, ...updates } : p)
        })),

      deletePin: (pinId) =>
        set(state => ({ pins: state.pins.filter(p => p.id !== pinId) })),

      addTag: (tag) =>
        set(state => ({
          tags: state.tags.includes(tag) ? state.tags : [...state.tags, tag]
        })),
    }),
    { name: 'scrapbook-clipboard' }
  )
)

export { detectPinType, extractTweetId }
export default useClipboardStore
