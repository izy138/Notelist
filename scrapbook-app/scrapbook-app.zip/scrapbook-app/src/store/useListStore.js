import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { nanoid } from 'nanoid'

const LIST_TYPES = {
  grocery: { label: 'Grocery', emoji: '🛒', color: '#16a34a' },
  todo: { label: 'To-Do', emoji: '✅', color: '#2C3E6B' },
  shopping: { label: 'Shopping', emoji: '🛍️', color: '#9333ea' },
  future: { label: 'Someday', emoji: '🗓️', color: '#E8A030' },
  custom: { label: 'Custom', emoji: '📝', color: '#6b7280' },
}

export { LIST_TYPES }

const useListStore = create(
  persist(
    (set, get) => ({
      lists: [],
      
      addList: ({ name, type = 'todo', emoji, color, dueDate }) => {
        const typeDefaults = LIST_TYPES[type] || LIST_TYPES.custom
        set(state => ({
          lists: [
            {
              id: nanoid(),
              name,
              type,
              emoji: emoji || typeDefaults.emoji,
              color: color || typeDefaults.color,
              dueDate: dueDate || null,
              createdAt: Date.now(),
              items: [],
              archivedItems: [],
            },
            ...state.lists,
          ]
        }))
      },

      updateList: (listId, updates) =>
        set(state => ({
          lists: state.lists.map(l => l.id === listId ? { ...l, ...updates } : l)
        })),

      deleteList: (listId) =>
        set(state => ({ lists: state.lists.filter(l => l.id !== listId) })),

      addItem: (listId, text) => {
        if (!text.trim()) return
        set(state => ({
          lists: state.lists.map(l =>
            l.id === listId
              ? { ...l, items: [...l.items, { id: nanoid(), text: text.trim(), note: '', checked: false, createdAt: Date.now() }] }
              : l
          )
        }))
      },

      updateItem: (listId, itemId, updates) =>
        set(state => ({
          lists: state.lists.map(l =>
            l.id === listId
              ? { ...l, items: l.items.map(i => i.id === itemId ? { ...i, ...updates } : i) }
              : l
          )
        })),

      checkItem: (listId, itemId) => {
        const list = get().lists.find(l => l.id === listId)
        if (!list) return
        const item = list.items.find(i => i.id === itemId)
        if (!item) return
        // Move to archive
        set(state => ({
          lists: state.lists.map(l =>
            l.id === listId
              ? {
                  ...l,
                  items: l.items.filter(i => i.id !== itemId),
                  archivedItems: [{ ...item, archivedAt: Date.now() }, ...l.archivedItems],
                }
              : l
          )
        }))
      },

      unarchiveItem: (listId, itemId) => {
        const list = get().lists.find(l => l.id === listId)
        if (!list) return
        const item = list.archivedItems.find(i => i.id === itemId)
        if (!item) return
        set(state => ({
          lists: state.lists.map(l =>
            l.id === listId
              ? {
                  ...l,
                  archivedItems: l.archivedItems.filter(i => i.id !== itemId),
                  items: [...l.items, { ...item, checked: false, archivedAt: undefined }],
                }
              : l
          )
        }))
      },

      deleteItem: (listId, itemId) =>
        set(state => ({
          lists: state.lists.map(l =>
            l.id === listId
              ? { ...l, items: l.items.filter(i => i.id !== itemId) }
              : l
          )
        })),

      deleteArchivedItem: (listId, itemId) =>
        set(state => ({
          lists: state.lists.map(l =>
            l.id === listId
              ? { ...l, archivedItems: l.archivedItems.filter(i => i.id !== itemId) }
              : l
          )
        })),

      clearArchive: (listId) =>
        set(state => ({
          lists: state.lists.map(l =>
            l.id === listId ? { ...l, archivedItems: [] } : l
          )
        })),

      reorderItems: (listId, newItems) =>
        set(state => ({
          lists: state.lists.map(l =>
            l.id === listId ? { ...l, items: newItems } : l
          )
        })),
    }),
    { name: 'scrapbook-lists' }
  )
)

export default useListStore
